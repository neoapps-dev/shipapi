# BDK/BatDK (Batch Development Kit)
Welcome to the official BDK github repo!
here, you will find the full source code for BDK!

## How To Install ?
to install **BDK** on your computer, follow these steps,

- Download the latest **setup** from [Releases](https://github.com/neoapps-dev/bdk/releases)
- Launch the file as **Administrator**
- Follow the steps on the screen :)

## How can i contribute ?
easy, 
- **Fork** this repo.
- Make change on **your** repo
- Make a [PR](https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/proposing-changes-to-your-work-with-pull-requests/about-pull-requests) and wait until an admin will review your changes and then merge them.

## How to use BDK ?
- run `bdk init` in CMD/Terminal/BatchFile.
- you can know use all BDK commands! try `echo %@.version%` to confirm that everything works perfectly!