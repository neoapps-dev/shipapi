
# Project: BatDBug - by Kvc
## v20220417
1. Added Support for Finding Line which is creating error in Big batch files.
2. Added support for interactive progress bar for the background activity.


www.batch-man.com
